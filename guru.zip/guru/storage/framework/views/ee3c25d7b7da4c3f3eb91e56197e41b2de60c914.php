<?php /* W:\domains\guru\resources\views/auth/login.blade.php */ ?>
<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('headAssetsSection'); ?>

<?php $__env->startSection('content'); ?>

    <div id="registrationWrapper">
        <h1>Login</h1>
        <form id="registration" class="formBody" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="inputRow">
                <div class="formInner">
                    <label for="">Email</label>
                    <input type="email" name="email" placeholder="Email" required>
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
            <div class="inputRow">
                <div class="formInner">
                    <label for="">Password</label>
                    <input type="password" name="password" placeholder="Password" required>
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
            <div class="inputRow">
                <div class="formInner jc-space-between">
                    <input type="checkbox" class="checkbox" id="register_checkbox" />
                    <label for="register_checkbox">Keep me logged in</label>
                    <a href="<?php echo e(route('password.request')); ?>" class="forgot">Forgot password?</a>
                </div>
            </div>
            <button name="submit" type="submit">Sign In</button>
            <a href="<?php echo e(route('register')); ?>" class="register">Don`t have an account?</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>