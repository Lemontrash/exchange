<?php /* W:\domains\guru\resources\views/scriptAssets.blade.php */ ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/intlTelInput.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>