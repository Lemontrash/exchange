<?php /* W:\domains\guru\resources\views/admin/accountVerificationFiles.blade.php */ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
</head>
<body>
    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button>
            <a href="/admin/download/<?php echo e($file->file_id); ?>">User id: <?php echo e($file->user_id); ?></a>
        </button> <br>
        <button>
            <a href="<?php echo e($file->selfie); ?>" download="">User selfie: <?php echo e($file->user_id); ?>

                <img src="/storage/<?php echo e($file->selfie); ?>" alt="">
            </a>
        </button> <br><button>
            <a href="/admin/download/<?php echo e($file->bank); ?>">User bank: <?php echo e($file->user_id); ?></a>
        </button> <br>
        <button>
            <a href="/admin/download/<?php echo e($file->dod); ?>">User dod: <?php echo e($file->user_id); ?></a>
        </button> <br>
        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>