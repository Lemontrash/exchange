<?php /* W:\domains\guru\resources\views/auth/register.blade.php */ ?>
<?php $__env->startSection('title'); ?>
  Registration
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('headAssetsSection'); ?>

<?php $__env->startSection('content'); ?>
<div id="registrationWrapper">
  <h1>Registration</h1>
  <form id="registration" class="formBody" method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>
    <div class="inputRow">
      <div class="formInner">
        <label for="accountType">Account</label>
        <select name="accountType" class="">
          <option value="Individual" selected>Individual</option>
          <option value="Business">Business</option>
        </select>
      </div>
      <div class="formInner">
        <label for="">Email</label>
        <input type="email" name="email" placeholder="Email" required>
        <i class="fas fa-check-circle"></i>
      </div>
    </div>
    <div class="inputRow">
      <div class="formInner">
        <label for="">First Name</label>
        <input type="text" name="firstName" placeholder="First" required>
        <i class="fas fa-check-circle"></i>
      </div>
      <div class="formInner">
        <label for="">Last Name</label>
        <input type="text" name="lastName" placeholder="Last" required>
        <i class="fas fa-check-circle"></i>
      </div>
    </div>
    <div class="inputRow">
      <div class="formInner">
        <label for="">Password</label>
        <input type="password" name="password" placeholder="Password" required>
        <i class="fas fa-check-circle"></i>
      </div>
      <div class="formInner">
        <label for="">Phone Number</label>
        <input type="tel" name="phoneNumber" placeholder="Phone Number" id="phoneNumber" required>
        <!-- <i class="fas fa-check-circle"></i> -->
      </div>
    </div>
    <p class="agreement">By clicking on Open Account, I declare I am over 18 years <br> and I agree to AAATrace's <a href="/terms-and-conditions">Terms & Conditions</a></p>
    <button name="submit" type="submit">Sign Up</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
        

<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>