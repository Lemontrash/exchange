<?php /* W:\domains\guru\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php */ ?>
<?php echo e($slot); ?>

