<?php /* W:\domains\guru\resources\views/forms.blade.php */ ?>

<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
       	<?php echo $__env->make('headAssets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>
   
    <body>
    	<div class="formsWrapper">
    		<div id="backArrow"><a style="color: whitesmoke; text-decoration: none;" href="<?php echo e(redirect('home')); ?>"><i class="fal fa-long-arrow-left"></i> Back</a></div>
    		<?php echo $__env->yieldContent('content'); ?>
    	</div>
        <?php echo $__env->make('scriptAssets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>