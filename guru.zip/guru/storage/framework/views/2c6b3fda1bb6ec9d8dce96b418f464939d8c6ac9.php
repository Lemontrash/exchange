<?php /* W:\domains\guru\resources\views/profileAdminPanel.blade.php */ ?>
<html>
    <head>
        <title>Profile</title>
        <?php echo $__env->make('headAssets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link href="<?php echo e(asset('css/common.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">
      <style>
        a{
          text-decoration: none;
        }
      </style>
    </head>
   
    <body>
      
      <header id="profile_header">
        <div class="logo-wrap">
          <a href="/">
            <img src="/img/logo.png" alt="">
          </a>
        </div>

        <div class="header-search-wrapper">
          <form class="header-search">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit">
              <i class="fas fa-search"></i>
            </button>
          </form>
        </div>

        <div class="profile-avatar profile-header-btn">
          <div class="img-wrap">
            <img src="/img/profile-avatar.png" alt="">
          </div>
        </div>

        <div class="notifications profile-header-btn">
          <div class="ico-wrap">
            <i class="fas fa-bell"></i>
          </div>
        </div>

        <div class="dots-wrapper profile-header-btn">
          <div class="ico-wrap">
            <i class="fas fa-ellipsis-h"></i>
          </div>
        </div>
      </header>

      <aside class="profile-nav">
        <ul class="links-container">
          <li class="link-item">
            <i class="fas fa-check-circle"></i>
            <a style="color: grey"  href="#">
              Exchange
            </a>
          </li>
          <li class="link-item">
            <i class="fas fa-exchange"></i>
            <a style="color: grey" href="/">
              Currancy Rate
            </a>

          </li>
          <li class="link-item">
            <i class="fas fa-chart-bar"></i>
            <a style="color: grey" href="<?php echo e(route('FilesHistory')); ?>">
              Transition
            </a>
          </li>
          <li class="link-item">
            <i class="fas fa-envelope"></i>
            <a style="color: grey" href="">
              Contact
            </a>
          </li>
          <li class="link-item">
            <i class="fas fa-question"></i>
            <a style="color: grey" href="<?php echo e(route('Faq')); ?>">
              FAQ
            </a>

          </li>
          <li class="link-item">
            <i class="fas fa-cog"></i>
            <a style="color: grey" href="<?php echo e(route('profile')); ?>">
              Settings
            </a>
          </li>
          <li class="link-item">
            <i class="fas fa-cog"></i>
            <a style="color: grey" href="<?php echo e(route('profile')); ?>">
              Admin
            </a>
          </li>
        </ul>
      </aside>

      <div class="profile-content">
        <div class="page-title">ADMIN PANEL</div>
       
        <table class="table" id="">
          <thead>
            <tr>
              <th>Name</th>
              <th>Registration Date</th>
              <th>Phone</th>
              <th class="text-center">Email</th>
              <th class="text-center">Aproved</th>
              <th class="text-center">Account</th>
            </tr>
          </thead>
          <tbody>
            <tr class="user">
              <th>John Snow</th>
              <th>02 / 02 /2019</th>
              <th>+380557744876</th>
              <th>Johnsnow14@gmail.com</th>
              <th class="text-center"><i class="fas fa-check-circle"></i></th>
              <th class="text-center">Individual</th>
            </tr>
            
          </tbody>
        </table>
      </div>

      <?php echo $__env->make('scriptAssets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>