<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusinessIndividuals extends Model
{

}
