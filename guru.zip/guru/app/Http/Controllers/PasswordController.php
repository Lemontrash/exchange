<?php

namespace App\Http\Controllers;

use App\User;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use function MongoDB\BSON\toJSON;
use phpseclib\Crypt\Random;

class PasswordController extends Controller
{
    public function changePassword(Request $request){
//        $a = 12;
//        $b = Hash::make(12);
//        $c = Hash::check($a, $b);
//        return $c;
    //return \response()->json('success');
        $user = User::find(1);
        $currentPassword = $request->get('password');
        $newPassword = $request->get('new_password');
//        dd($user);
        if(true){
            $user->password = Hash::make($newPassword);
            $user->save();
            return response()->json('success', 200);
        }else{
            return \response()->json('no');
        }
    }
}
