<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,700i,900&amp;subset=cyrillic,hebrew" rel="stylesheet">
<link href="{{ asset('css/font-awesome/css/fontawesome-all.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/nice-select.css') }}" rel="stylesheet">
<link href="{{ asset('css/intlTelInput.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/styles.css') }}" rel="stylesheet">


