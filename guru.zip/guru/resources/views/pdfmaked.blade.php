<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>
<p style="font-family: Varela Round , sans-serif;">献给母syka blyat亲的爱</p>
</body>
</html>
{{--{{$firstName}}          <br>--}}
{{--{{$secondName}}<br>--}}
{{--{{$lastName}}<br>--}}
{{--{{$country}}<br>--}}
{{--{{$citizenship}}<br>--}}
{{--{{$placeOfBirth}}<br>--}}
{{--{{$address}}<br>--}}
{{--{{$landLine}}<br>--}}
{{--{{$city}}<br>--}}
{{--{{$zip}}<br>--}}
{{--{{$employment}}<br>--}}
{{--{{$industry}}<br>--}}
{{--{{$annualIncome}}<br>--}}
{{--{{$savings}}<br>--}}
{{--{{$sourceOfFunds}}<br>--}}
{{--{{$investAnnually}}<br>--}}
{{--{{$nameOfBank}}<br>--}}
{{--{{$taxId}}<br>--}}
{{--{{$countryTaxes}}<br>--}}