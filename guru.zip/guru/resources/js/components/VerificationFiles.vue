<template>
    <form id="upload_files" class="formBody" method="POST" action="">
        @csrf
        <div class="theme-row">
            <div class="inp-group text-inp-group">
              <label for="" class="inp-caption" id="">ID picture</label>
              <div class="inp-wrap">
                <input type="text" name="" placeholder="File">
                <i class="fas fa-check-circle"></i>
              </div>
            </div>
            <label class="theme-btn upload-btn">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
                    <path d="M 6 3 C 4.895 3 4 3.895 4 5 L 4 22 C 4 23.105 4.895 24 6 24 L 14 24 L 14 11.414062 L 11.707031 13.707031 C 11.316031 14.098031 10.683969 14.098031 10.292969 13.707031 C 9.9019687 13.316031 9.9019687 12.683969 10.292969 12.292969 L 14.292969 8.2929688 C 14.487969 8.0979687 14.744 8 15 8 C 15.256 8 15.512031 8.0979688 15.707031 8.2929688 L 19.707031 12.292969 C 20.098031 12.683969 20.098031 13.316031 19.707031 13.707031 C 19.316031 14.098031 18.683969 14.098031 18.292969 13.707031 L 16 11.414062 L 16 24 L 24 24 C 25.105 24 26 23.105 26 22 L 26 5 C 26 3.895 25.105 3 24 3 L 6 3 z M 16 24 L 14 24 L 14 28 C 14 28.552 14.448 29 15 29 C 15.552 29 16 28.552 16 28 L 16 24 z"/>
                </svg>
                Upload
                <input type="file" accept="image/*" name="">
            </label>
        </div>

        <div class="theme-row">
            <div class="inp-group text-inp-group">
              <label for="" class="inp-caption" id="">Selfi picture</label>
              <div class="inp-wrap">
                <input type="text" name="" placeholder="File">
                <i class="fas fa-check-circle"></i>
              </div>
            </div>
            <label class="theme-btn upload-btn">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
                    <path d="M 6 3 C 4.895 3 4 3.895 4 5 L 4 22 C 4 23.105 4.895 24 6 24 L 14 24 L 14 11.414062 L 11.707031 13.707031 C 11.316031 14.098031 10.683969 14.098031 10.292969 13.707031 C 9.9019687 13.316031 9.9019687 12.683969 10.292969 12.292969 L 14.292969 8.2929688 C 14.487969 8.0979687 14.744 8 15 8 C 15.256 8 15.512031 8.0979688 15.707031 8.2929688 L 19.707031 12.292969 C 20.098031 12.683969 20.098031 13.316031 19.707031 13.707031 C 19.316031 14.098031 18.683969 14.098031 18.292969 13.707031 L 16 11.414062 L 16 24 L 24 24 C 25.105 24 26 23.105 26 22 L 26 5 C 26 3.895 25.105 3 24 3 L 6 3 z M 16 24 L 14 24 L 14 28 C 14 28.552 14.448 29 15 29 C 15.552 29 16 28.552 16 28 L 16 24 z"/>
                </svg>
                Upload
                <input type="file" accept="image/*" name="">
            </label>
        </div>

        <div class="theme-row">
            <div class="inp-group text-inp-group">
              <label for="" class="inp-caption" id="">Bank transfer </label>
              <div class="inp-wrap">
                <input type="text" name="" placeholder="File">
                <i class="fas fa-check-circle"></i>
              </div>
            </div>
            <label class="theme-btn upload-btn">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
                    <path d="M 6 3 C 4.895 3 4 3.895 4 5 L 4 22 C 4 23.105 4.895 24 6 24 L 14 24 L 14 11.414062 L 11.707031 13.707031 C 11.316031 14.098031 10.683969 14.098031 10.292969 13.707031 C 9.9019687 13.316031 9.9019687 12.683969 10.292969 12.292969 L 14.292969 8.2929688 C 14.487969 8.0979687 14.744 8 15 8 C 15.256 8 15.512031 8.0979688 15.707031 8.2929688 L 19.707031 12.292969 C 20.098031 12.683969 20.098031 13.316031 19.707031 13.707031 C 19.316031 14.098031 18.683969 14.098031 18.292969 13.707031 L 16 11.414062 L 16 24 L 24 24 C 25.105 24 26 23.105 26 22 L 26 5 C 26 3.895 25.105 3 24 3 L 6 3 z M 16 24 L 14 24 L 14 28 C 14 28.552 14.448 29 15 29 C 15.552 29 16 28.552 16 28 L 16 24 z"/>
                </svg>
                Upload
                <input type="file" accept="image/*" name="">
            </label>
        </div>

        <div class="theme-row">
            <div class="inp-group text-inp-group">
              <label for="" class="inp-caption" id="">DOD</label>
              <div class="inp-wrap">
                <input type="text" name="" placeholder="File">
                <i class="fas fa-check-circle"></i>
              </div>
            </div>
            <label class="theme-btn upload-btn">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
                    <path d="M 6 3 C 4.895 3 4 3.895 4 5 L 4 22 C 4 23.105 4.895 24 6 24 L 14 24 L 14 11.414062 L 11.707031 13.707031 C 11.316031 14.098031 10.683969 14.098031 10.292969 13.707031 C 9.9019687 13.316031 9.9019687 12.683969 10.292969 12.292969 L 14.292969 8.2929688 C 14.487969 8.0979687 14.744 8 15 8 C 15.256 8 15.512031 8.0979688 15.707031 8.2929688 L 19.707031 12.292969 C 20.098031 12.683969 20.098031 13.316031 19.707031 13.707031 C 19.316031 14.098031 18.683969 14.098031 18.292969 13.707031 L 16 11.414062 L 16 24 L 24 24 C 25.105 24 26 23.105 26 22 L 26 5 C 26 3.895 25.105 3 24 3 L 6 3 z M 16 24 L 14 24 L 14 28 C 14 28.552 14.448 29 15 29 C 15.552 29 16 28.552 16 28 L 16 24 z"/>
                </svg>
                Upload
                <input type="file" accept="image/*" name="">
            </label>
        </div>

        <div class="theme-row all-file-upload drop-area">
            <input type="file" accept="image/*" multiple>
            <div class="text-col">
                <p>Drop files here, paste, or import from one of the locations above</p>
                <small>jpg, png,svg pull up to 1 MB</small>
            </div>
            <div class="img-col">
                <img src="/img/ico-files.png" alt="">
            </div>
        </div>

        <div class="theme-row">
            <button type="submit" class="theme-btn btn-blue w-100 ttu jc-center">Continue</button>
        </div>
    </form>
</template>

<script>
    export default {
        props: [
            'ajaxurl'
        ],
        mounted() {
            console.log(this.ajaxurl);
        }
    }
</script>
